CREATE TRIGGER T_USER_TGR
  BEFORE INSERT
  ON T_USER
  FOR EACH ROW
  BEGIN
  select t_user_seq.nextval into :new.user_id from dual;
END;
/

